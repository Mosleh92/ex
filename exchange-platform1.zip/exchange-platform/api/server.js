cat > api/server.js << 'API_END'
import express from 'express';
import cors from 'cors';
const app = express();
const PORT = 5000;
app.use(cors());
app.use(express.json());
// Health check
app.get('/api/health', (req, res) => {
    res.json({
        status: 'OK',
        message: 'Exchange Platform API is running!',
        timestamp: new Date().toISOString()
    });
});
// Get exchangers
app.get('/api/exchangers', (req, res) => {
    res.json({
        success: true,
        data: [
            { id: 'demo', name: 'Demo Exchange', customers: 15420 }
        ]
    });
});
app.listen(PORT, () => {
    console.log(`🚀 API Server: http://localhost:${PORT}`);
    console.log(`📊 Health: http://localhost:${PORT}/api/health`);
});
