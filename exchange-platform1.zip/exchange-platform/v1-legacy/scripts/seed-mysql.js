// scripts/seed-data.js
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');
const path = require('path');
require('dotenv').config();

const dbPath = process.env.DB_PATH || path.join(__dirname, '..', 'exchange_platform.db');

async function seedDatabase() {
  console.log('🌱 Starting database seeding...');
  
  const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
      console.error('❌ Database connection failed:', err.message);
      process.exit(1);
    }
    console.log('✅ Connected to database for seeding');
  });

  try {
    // Clear existing data (optional - remove if you want to keep existing data)
    console.log('🧹 Clearing existing sample data...');
    
    await runQuery(db, 'DELETE FROM audit_logs WHERE user_id IN (SELECT id FROM platform_users WHERE email LIKE "%@example.com")');
    await runQuery(db, 'DELETE FROM tenant_transactions WHERE tenant_id IN ("DEMO_001", "DEMO_002", "TEST_003")');
    await runQuery(db, 'DELETE FROM commission_rates WHERE tenant_id IN ("DEMO_001", "DEMO_002", "TEST_003")');
    await runQuery(db, 'DELETE FROM exchange_rates WHERE tenant_id IN ("DEMO_001", "DEMO_002", "TEST_003")');
    await runQuery(db, 'DELETE FROM tenant_users WHERE tenant_id IN ("DEMO_001", "DEMO_002", "TEST_003")');
    await runQuery(db, 'DELETE FROM platform_users WHERE tenant_id IN ("DEMO_001", "DEMO_002", "TEST_003")');
    await runQuery(db, 'DELETE FROM tenants WHERE tenant_id IN ("DEMO_001", "DEMO_002", "TEST_003")');

    // Create sample tenants
    console.log('🏢 Creating sample tenants...');
    
    const sampleTenants = [
      {
        tenant_id: 'DEMO_001',
        name: 'صرافی دمو اول',
        subdomain: 'demo1',
        plan: 'professional',
        status: 'active',
        admin_email: 'admin@demo1.com',
        admin_phone: '+98 21 1111 1111',
        exchange_address: 'تهران، خیابان فردوسی، پلاک 123',
        business_license: 'LIC-DEMO-001'
      },
      {
        tenant_id: 'DEMO_002',
        name: 'صرافی دمو دوم',
        subdomain: 'demo2',
        plan: 'basic',
        status: 'active',
        admin_email: 'admin@demo2.com',
        admin_phone: '+98 21 2222 2222',
        exchange_address: 'تهران، خیابان ولیعصر، پلاک 456',
        business_license: 'LIC-DEMO-002'
      },
      {
        tenant_id: 'TEST_003',
        name: 'صرافی تست',
        subdomain: 'test',
        plan: 'enterprise',
        status: 'pending',
        admin_email: 'admin@test.com',
        admin_phone: '+98 21 3333 3333',
        exchange_address: 'تهران، خیابان انقلاب، پلاک 789',
        business_license: 'LIC-TEST-003'
      }
    ];

    for (const tenant of sampleTenants) {
      await runQuery(db, `
        INSERT INTO tenants (tenant_id, name, subdomain, plan, status, admin_email, admin_phone, exchange_address, business_license, approved_at, expires_at, settings)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now', '+1 year'), ?)
      `, [
        tenant.tenant_id, tenant.name, tenant.subdomain, tenant.plan, 
        tenant.status, tenant.admin_email, tenant.admin_phone, 
        tenant.exchange_address, tenant.business_license,
        JSON.stringify({
          theme: 'default',
          language: 'fa',
          notifications: {
            email: true,
            sms: true,
            whatsapp: false
          },
          features: {
            p2p_customer: tenant.plan !== 'basic',
            p2p_exchanger: true,
            advanced_reports: tenant.plan === 'enterprise'
          }
        })
      ]);

      // Create tenant admin
      const adminPassword = await bcrypt.hash('Admin@123456', 12);
      await runQuery(db, `
        INSERT INTO platform_users (email, password_hash, role, tenant_id, name, phone, status, settings)
        VALUES (?, ?, 'tenant_admin', ?, ?, ?, 'active', ?)
      `, [
        tenant.admin_email, adminPassword, tenant.tenant_id, 
        `مدیر ${tenant.name}`, tenant.admin_phone,
        JSON.stringify({
          dashboard_layout: 'default',
          notification_preferences: {
            new_transactions: true,
            system_alerts: true,
            financial_reports: true
          }
        })
      ]);

      // Create sample users for each tenant
      if (tenant.status === 'active') {
        console.log(`👥 Creating sample users for ${tenant.name}...`);
        
        const sampleUsers = [
          {
            email: `employee1@${tenant.subdomain}.com`,
            name: 'کارمند اول',
            role: 'employee',
            phone: '+98 912 111 1111'
          },
          {
            email: `customer1@${tenant.subdomain}.com`,
            name: 'مشتری اول',
            role: 'customer',
            phone: '+98 912 222 2222',
            p2p_enabled: true,
            kyc_status: 'approved'
          },
          {
            email: `customer2@${tenant.subdomain}.com`,
            name: 'مشتری دوم',
            role: 'customer',
            phone: '+98 912 333 3333',
            p2p_enabled: false,
            kyc_status: 'pending'
          }
        ];

        for (const user of sampleUsers) {
          const userPassword = await bcrypt.hash('User@123456', 12);
          await runQuery(db, `
            INSERT INTO tenant_users (tenant_id, email, password_hash, name, role, phone, status, p2p_enabled, kyc_status, balance, settings)
            VALUES (?, ?, ?, ?, ?, ?, 'active', ?, ?, ?, ?)
          `, [
            tenant.tenant_id, user.email, userPassword, user.name, 
            user.role, user.phone, user.p2p_enabled || false, 
            user.kyc_status || 'pending', user.role === 'customer' ? 1000.00 : 0.00,
            JSON.stringify({
              preferred_currency: 'USD',
              notification_methods: ['email', 'sms']
            })
          ]);
        }

        // Create exchange rates for active tenants
        console.log(`💱 Creating exchange rates for ${tenant.name}...`);
        
        const exchangeRates = [
          { from: 'USD', to: 'IRR', buy: 42000.00, sell: 42500.00, markup: 1.2 },
          { from: 'EUR', to: 'IRR', buy: 45000.00, sell: 45600.00, markup: 1.3 },
          { from: 'GBP', to: 'IRR', buy: 52000.00, sell: 52700.00, markup: 1.4 },
          { from: 'AED', to: 'IRR', buy: 11400.00, sell: 11500.00, markup: 0.9 }
        ];

        for (const rate of exchangeRates) {
          await runQuery(db, `
            INSERT INTO exchange_rates (tenant_id, currency_from, currency_to, buy_rate, sell_rate, markup_percentage, is_active)
            VALUES (?, ?, ?, ?, ?, ?, 1)
          `, [tenant.tenant_id, rate.from, rate.to, rate.buy, rate.sell, rate.markup]);
        }

        // Create commission rates
        console.log(`💰 Creating commission rates for ${tenant.name}...`);
        
        const commissionRates = [
          { type: 'buy', rate_type: 'percentage', rate_value: 1.50, currency: 'USD' },
          { type: 'sell', rate_type: 'percentage', rate_value: 1.25, currency: 'USD' },
          { type: 'p2p_customer', rate_type: 'percentage', rate_value: 2.00, currency: 'USD' },
          { type: 'p2p_exchanger', rate_type: 'percentage', rate_value: 1.00, currency: 'USD' }
        ];

        for (const commission of commissionRates) {
          await runQuery(db, `
            INSERT INTO commission_rates (tenant_id, transaction_type, rate_type, rate_value, currency, is_active)
            VALUES (?, ?, ?, ?, ?, 1)
          `, [tenant.tenant_id, commission.type, commission.rate_type, commission.rate_value, commission.currency]);
        }

        // Create sample transactions
        console.log(`💳 Creating sample transactions for ${tenant.name}...`);
        
        // Get user IDs for this tenant
        const users = await getAllQuery(db, 'SELECT id, role FROM tenant_users WHERE tenant_id = ?', [tenant.tenant_id]);
        
        if (users.length > 0) {
          const sampleTransactions = [
            {
              user_id: users.find(u => u.role === 'customer')?.id,
              type: 'buy',
              amount: 1000.00,
              currency_from: 'USD',
              currency_to: 'IRR',
              exchange_rate: 42000.00,
              commission: 15.00,
              status: 'completed',
              description: 'خرید دلار آمریکا',
              customer_name: 'احمد محمدی',
              customer_phone: '+98 912 111 1111',
              payment_method: 'cash'
            },
            {
              user_id: users.find(u => u.role === 'customer')?.id,
              type: 'sell',
              amount: 500.00,
              currency_from: 'EUR',
              currency_to: 'IRR',
              exchange_rate: 45000.00,
              commission: 6.25,
              status: 'completed',
              description: 'فروش یورو',
              customer_name: 'فاطمه احمدی',
              customer_phone: '+98 912 222 2222',
              payment_method: 'bank_transfer'
            },
            {
              user_id: users.find(u => u.role === 'customer')?.id,
              type: 'buy',
              amount: 2000.00,
              currency_from: 'USD',
              currency_to: 'IRR',
              exchange_rate: 42100.00,
              commission: 30.00,
              status: 'pending',
              description: 'خرید دلار آمریکا - در انتظار تأیید',
              customer_name: 'علی رضایی',
              customer_phone: '+98 912 333 3333',
              payment_method: 'cash'
            }
          ];

          for (const [index, transaction] of sampleTransactions.entries()) {
            const netAmount = transaction.amount - transaction.commission;
            const referenceId = `TXN-${tenant.tenant_id}-${Date.now()}-${index}`;
            const receiptNumber = `RCP-${Math.random().toString(36).substr(2, 8).toUpperCase()}`;

            await runQuery(db, `
              INSERT INTO tenant_transactions (
                tenant_id, user_id, type, amount, currency_from, currency_to, 
                exchange_rate, commission, commission_percentage, net_amount, status, 
                description, reference_id, receipt_number, payment_method, 
                customer_name, customer_phone, completed_at, metadata
              ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `, [
              tenant.tenant_id, transaction.user_id, transaction.type, 
              transaction.amount, transaction.currency_from, transaction.currency_to,
              transaction.exchange_rate, transaction.commission, 
              (transaction.commission / transaction.amount * 100).toFixed(4),
              netAmount, transaction.status, transaction.description,
              referenceId, receiptNumber, transaction.payment_method,
              transaction.customer_name, transaction.customer_phone,
              transaction.status === 'completed' ? new Date().toISOString() : null,
              JSON.stringify({
                created_via: 'seed_script',
                notes: 'Sample transaction for testing'
              })
            ]);
          }
        }
      }
    }

    console.log('✅ Database seeding completed successfully!');
    console.log('\n🔐 Sample login credentials:');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('Super Admin:');
    console.log('  Email: super@admin.com');
    console.log('  Password: SuperAdmin@2024!');
    console.log('\nTenant Admins:');
    console.log('  Email: admin@demo1.com');
    console.log('  Password: Admin@123456');
    console.log('  Email: admin@demo2.com');
    console.log('  Password: Admin@123456');
    console.log('\nSample Users:');
    console.log('  Email: customer1@demo1.com');
    console.log('  Password: User@123456');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

  } catch (error) {
    console.error('❌ Seeding failed:', error);
  } finally {
    db.close((err) => {
      if (err) {
        console.error('❌ Error closing database:', err.message);
      } else {
        console.log('✅ Database connection closed');
      }
      process.exit(0);
    });
  }
}

// Helper functions
function runQuery(db, sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function(err) {
      if (err) {
        reject(err);
      } else {
        resolve(this);
      }
    });
  });
}

function getAllQuery(db, sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) {
        reject(err);
      } else {
        resolve(rows);
      }
    });
  });
}

// Run seeding if called directly
if (require.main === module) {
  seedDatabase();
}

module.exports = { seedDatabase };