// netlify/functions/rates.js  
const { getDatabase, authenticateToken } = require('../../src/database');

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization', 
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const authHeader = event.headers.authorization;
    const token = authHeader && authHeader.split(' ')[1];
    
    if (!token) {
      return {
        statusCode: 401,
        headers,
        body: JSON.stringify({ error: 'Access token required' })
      };
    }

    const user = await authenticateToken(token);
    if (!user) {
      return {
        statusCode: 403,
        headers,
        body: JSON.stringify({ error: 'Invalid token' })
      };
    }

    const db = await getDatabase();
    const { tenant_id } = event.queryStringParameters || {};
    const targetTenantId = tenant_id || user.tenantId;

    if (event.httpMethod === 'GET') {
      // دریافت نرخ‌های ارز
      const rates = await new Promise((resolve, reject) => {
        db.all('SELECT * FROM exchange_rates WHERE tenant_id = ? ORDER BY updated_at DESC', [targetTenantId], (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        });
      });

      // دریافت نرخ‌های کارمزد
      const commissionRates = await new Promise((resolve, reject) => {
        db.all('SELECT * FROM commission_rates WHERE tenant_id = ? ORDER BY created_at DESC', [targetTenantId], (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        });
      });

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ 
          success: true, 
          data: { 
            exchange_rates: rates,
            commission_rates: commissionRates
          }
        })
      };

    } else if (event.httpMethod === 'POST') {
      const { type, ...data } = JSON.parse(event.body);

      if (type === 'exchange_rate') {
        // تنظیم نرخ ارز
        const { currency_from, currency_to, buy_rate, sell_rate, markup_percentage } = data;
        
        await new Promise((resolve, reject) => {
          db.run(`
            INSERT OR REPLACE INTO exchange_rates (tenant_id, currency_from, currency_to, buy_rate, sell_rate, markup_percentage, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, datetime('now'))
          `, [targetTenantId, currency_from, currency_to, buy_rate, sell_rate, markup_percentage], (err) => {
            if (err) reject(err);
            else resolve();
          });
        });

        return {
          statusCode: 201,
          headers,
          body: JSON.stringify({ success: true, message: 'Exchange rate updated' })
        };

      } else if (type === 'commission_rate') {
        // تنظیم نرخ کارمزد
        const { transaction_type, rate, min_amount, max_amount } = data;
        
        await new Promise((resolve, reject) => {
          db.run(`
            INSERT OR REPLACE INTO commission_rates (tenant_id, transaction_type, rate, min_amount, max_amount)
            VALUES (?, ?, ?, ?, ?)
          `, [targetTenantId, transaction_type, rate, min_amount, max_amount], (err) => {
            if (err) reject(err);
            else resolve();
          });
        });

        return {
          statusCode: 201,
          headers,
          body: JSON.stringify({ success: true, message: 'Commission rate updated' })
        };
      }
    }

  } catch (error) {
    console.error('Rates error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: 'Server error', details: error.message })
    };
  }
};
let exchangeRates = [];
let commissionRates = [];
let customerRates = []; // نرخ اختصاصی مشتریان

// شبیه‌سازی احراز هویت ساده
function authenticateToken(token) {
  if (!token) return null;
  return { id: 1, role: 'admin', tenantId: 1 };
}

// شبیه‌سازی دریافت نرخ آنلاین (مثلاً از یک API خارجی)
async function fetchOnlineRate(currency_from, currency_to) {
  // اینجا فقط شبیه‌سازی می‌شود
  const randomRate = (Math.random() * (60000 - 50000) + 50000).toFixed(2);
  return {
    buy_rate: Number(randomRate),
    sell_rate: Number((randomRate * 1.01).toFixed(2))
  };
}

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const authHeader = event.headers.authorization;
    const token = authHeader && authHeader.split(' ')[1];
    const user = authenticateToken(token);

    if (!user) {
      return {
        statusCode: 401,
        headers,
        body: JSON.stringify({ error: 'Access token required' })
      };
    }

    const { tenant_id = 1, customer_id, currency_from, currency_to, online } = event.queryStringParameters || {};
    const targetTenantId = tenant_id;

    if (event.httpMethod === 'GET') {
      // نرخ آنلاین
      if (online === '1' && currency_from && currency_to) {
        const onlineRate = await fetchOnlineRate(currency_from, currency_to);
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({ success: true, data: onlineRate, source: 'online' })
        };
      }

      // نرخ اختصاصی مشتری
      if (customer_id && currency_from && currency_to) {
        const found = customerRates.find(r =>
          String(r.tenant_id) === String(targetTenantId) &&
          String(r.customer_id) === String(customer_id) &&
          r.currency_from === currency_from &&
          r.currency_to === currency_to
        );
        if (found) {
          return {
            statusCode: 200,
            headers,
            body: JSON.stringify({ success: true, data: found, source: 'customer' })
          };
        }
      }

      // نرخ عمومی
      const rates = exchangeRates.filter(r => String(r.tenant_id) === String(targetTenantId));
      const commissions = commissionRates.filter(r => String(r.tenant_id) === String(targetTenantId));
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          success: true,
          data: {
            exchange_rates: rates,
            commission_rates: commissions,
            customer_rates: customerRates.filter(r => String(r.tenant_id) === String(targetTenantId))
          }
        })
      };
    }

    if (event.httpMethod === 'POST') {
      const { type, ...data } = JSON.parse(event.body);

      if (type === 'exchange_rate') {
        // ثبت نرخ ارز دستی
        const { currency_from, currency_to, buy_rate, sell_rate, markup_percentage } = data;
        if (!currency_from || !currency_to || typeof buy_rate !== 'number' || typeof sell_rate !== 'number') {
          return {
            statusCode: 400,
            headers,
            body: JSON.stringify({ error: 'Missing required fields' })
          };
        }
        // حذف قبلی و افزودن جدید
        exchangeRates = exchangeRates.filter(r =>
          !(r.tenant_id === targetTenantId && r.currency_from === currency_from && r.currency_to === currency_to)
        );
        exchangeRates.push({
          tenant_id: targetTenantId,
          currency_from,
          currency_to,
          buy_rate,
          sell_rate,
          markup_percentage,
          updated_at: new Date().toISOString()
        });
        return {
          statusCode: 201,
          headers,
          body: JSON.stringify({ success: true, message: 'Exchange rate updated' })
        };
      }

      if (type === 'commission_rate') {
        // ثبت نرخ کارمزد
        const { transaction_type, rate, min_amount, max_amount } = data;
        if (!transaction_type || typeof rate !== 'number') {
          return {
            statusCode: 400,
            headers,
            body: JSON.stringify({ error: 'Missing required fields' })
          };
        }
        commissionRates.push({
          tenant_id: targetTenantId,
          transaction_type,
          rate,
          min_amount,
          max_amount,
          created_at: new Date().toISOString()
        });
        return {
          statusCode: 201,
          headers,
          body: JSON.stringify({ success: true, message: 'Commission rate updated' })
        };
      }

      if (type === 'customer_rate') {
        // ثبت نرخ اختصاصی مشتری
        const { customer_id, currency_from, currency_to, buy_rate, sell_rate } = data;
        if (!customer_id || !currency_from || !currency_to || typeof buy_rate !== 'number' || typeof sell_rate !== 'number') {
          return {
            statusCode: 400,
            headers,
            body: JSON.stringify({ error: 'Missing required fields' })
          };
        }
        // حذف قبلی و افزودن جدید
        customerRates = customerRates.filter(r =>
          !(r.tenant_id === targetTenantId && r.customer_id === customer_id && r.currency_from === currency_from && r.currency_to === currency_to)
        );
        customerRates.push({
          tenant_id: targetTenantId,
          customer_id,
          currency_from,
          currency_to,
          buy_rate,
          sell_rate,
          updated_at: new Date().toISOString()
        });
        return {
          statusCode: 201,
          headers,
          body: JSON.stringify({ success: true, message: 'Customer rate updated' })
        };
      }
    }

    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method not allowed' })
    };

  } catch (error) {
    console.error('Rates error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: 'Server error', details: error.message })
    };
  }
};